import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import Header from './components/Layout/Header';
import Footer from './components/Layout/Footer';
import HomePage from './pages/HomePage';
import TherapistListPage from './pages/TherapistListPage';
import TherapistDetailPage from './pages/TherapistDetailPage';
import NotFoundPage from './pages/NotFoundPage';
import AdminLayout from './components/Layout/AdminLayout';
import AdminDashboardPage from './pages/Admin/AdminDashboardPage';
import AdminTherapistManagementPage from './pages/Admin/AdminTherapistManagementPage';
import AdminUserManagementPage from './pages/Admin/AdminUserManagementPage';
import AdminBookingManagementPage from './pages/Admin/AdminBookingManagementPage';
import { APP_ROUTES, APP_ADMIN_ROUTES } from './constants';

const UserLayout: React.FC = () => {
  return (
    <div className="flex flex-col min-h-screen bg-neutral-100">
      <Header />
      <main className="flex-grow container mx-auto px-4 py-8">
        <Routes>
          <Route path={APP_ROUTES.HOME} element={<HomePage />} />
          <Route path={APP_ROUTES.THERAPISTS} element={<TherapistListPage />} />
          <Route path={APP_ROUTES.THERAPIST_DETAIL_PARAM} element={<TherapistDetailPage />} />
          <Route path={APP_ROUTES.NOT_FOUND} element={<NotFoundPage />} />
          <Route path="*" element={<Navigate to={APP_ROUTES.NOT_FOUND} replace />} />
        </Routes>
      </main>
      <Footer />
    </div>
  );
};

const AdminRoutes: React.FC = () => {
  return (
    <AdminLayout>
      <Routes>
        <Route path={APP_ADMIN_ROUTES.DASHBOARD.substring(APP_ADMIN_ROUTES.DASHBOARD.lastIndexOf('/admin') + '/admin'.length) || '/'} element={<AdminDashboardPage />} />
        <Route path={APP_ADMIN_ROUTES.THERAPISTS.substring(APP_ADMIN_ROUTES.THERAPISTS.lastIndexOf('/admin') + '/admin'.length)} element={<AdminTherapistManagementPage />} />
        <Route path={APP_ADMIN_ROUTES.USERS.substring(APP_ADMIN_ROUTES.USERS.lastIndexOf('/admin') + '/admin'.length)} element={<AdminUserManagementPage />} />
        <Route path={APP_ADMIN_ROUTES.BOOKINGS.substring(APP_ADMIN_ROUTES.BOOKINGS.lastIndexOf('/admin') + '/admin'.length)} element={<AdminBookingManagementPage />} />
         <Route path="*" element={<Navigate to={APP_ADMIN_ROUTES.DASHBOARD.substring(APP_ADMIN_ROUTES.DASHBOARD.lastIndexOf('/admin') + '/admin'.length) || '/'} replace />} />
      </Routes>
    </AdminLayout>
  );
};


const App: React.FC = () => {
  return (
    <Routes>
      <Route path="/admin/*" element={<AdminRoutes />} />
      <Route path="/*" element={<UserLayout />} />
    </Routes>
  );
};

export default App;