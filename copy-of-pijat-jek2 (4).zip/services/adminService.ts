
import { Therapist, AdminUser, AdminBooking, TherapistAdminStatus, AdminUserStatus, AdminBookingStatus } from '../types';

const API_BASE_URL = '/api/admin'; // Assuming admin APIs are prefixed

// Fetch functions
export const fetchAdminTherapists = async (): Promise<Therapist[]> => {
  try {
    const response = await fetch(`${API_BASE_URL}/therapists`);
    if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
    return await response.json();
  } catch (error) {
    console.error("Failed to fetch admin therapists:", error);
    return [];
  }
};

export const fetchAdminUsers = async (): Promise<AdminUser[]> => {
  try {
    const response = await fetch(`${API_BASE_URL}/users`);
    if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
    return await response.json();
  } catch (error) {
    console.error("Failed to fetch admin users:", error);
    return [];
  }
};

export const fetchAdminBookings = async (): Promise<AdminBooking[]> => {
  try {
    const response = await fetch(`${API_BASE_URL}/bookings`);
    if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
    return await response.json();
  } catch (error) {
    console.error("Failed to fetch admin bookings:", error);
    return [];
  }
};

// Update status functions
export const updateTherapistStatus = async (therapistId: string, status: TherapistAdminStatus): Promise<Therapist | null> => {
  try {
    const response = await fetch(`${API_BASE_URL}/therapists/${therapistId}/status`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status }),
    });
    if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
    return await response.json();
  } catch (error) {
    console.error(`Failed to update status for therapist ${therapistId}:`, error);
    return null;
  }
};

export const updateUserStatus = async (userId: string, status: AdminUserStatus): Promise<AdminUser | null> => {
  try {
    const response = await fetch(`${API_BASE_URL}/users/${userId}/status`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status }),
    });
    if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
    return await response.json();
  } catch (error) {
    console.error(`Failed to update status for user ${userId}:`, error);
    return null;
  }
};

export const updateBookingStatus = async (bookingId: string, status: AdminBookingStatus): Promise<AdminBooking | null> => {
  try {
    const response = await fetch(`${API_BASE_URL}/bookings/${bookingId}/status`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status }),
    });
    if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
    return await response.json();
  } catch (error) {
    console.error(`Failed to update status for booking ${bookingId}:`, error);
    return null;
  }
};
