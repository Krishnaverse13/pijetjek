
import { Booking } from '../types'; // Assuming Booking type might be useful, though we send partial data

const API_BASE_URL = '/api';

interface BookingRequestData {
  therapistId: string;
  serviceId: string;
  serviceName: string; // Added for API convenience, might be looked up on backend too
  therapistName: string; // Added for API convenience
  date: string;
  time: string;
  notes?: string;
  price: number; // Added for API convenience
}

interface BookingResponse {
  success: boolean;
  message: string;
  bookingId?: string; // Optional: if backend returns an ID for the new booking
}

export const submitBooking = async (bookingDetails: BookingRequestData): Promise<BookingResponse> => {
  try {
    const response = await fetch(`${API_BASE_URL}/bookings`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(bookingDetails),
    });

    if (!response.ok) {
      // Try to parse error message from backend if available
      let errorMessage = `HTTP error! status: ${response.status}`;
      try {
        const errorData = await response.json();
        errorMessage = errorData.message || errorMessage;
      } catch (e) {
        // Ignore if error response is not JSON
      }
      throw new Error(errorMessage);
    }

    const data: BookingResponse = await response.json();
    return data;
  } catch (error) {
    console.error("Failed to submit booking:", error);
    return {
      success: false,
      message: error instanceof Error ? error.message : 'An unexpected error occurred during booking.',
    };
  }
};
