
import { Therapist } from '../types';

// Base API URL - in a real app, this might come from an environment variable
const API_BASE_URL = '/api'; // Assuming PHP backend is served from the same origin or proxied

export const fetchTherapists = async (): Promise<Therapist[]> => {
  try {
    const response = await fetch(`${API_BASE_URL}/therapists`);
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    const data: Therapist[] = await response.json();
    return data;
  } catch (error) {
    console.error("Failed to fetch therapists:", error);
    // In a real app, you might want to throw the error or return a default/empty array
    // and handle this in the UI (e.g., show an error message).
    return []; // Return empty array on error for now
  }
};

export const fetchTherapistById = async (id: string): Promise<Therapist | undefined> => {
  try {
    const response = await fetch(`${API_BASE_URL}/therapists/${id}`);
    if (!response.ok) {
      if (response.status === 404) {
        return undefined; // Therapist not found
      }
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    const data: Therapist = await response.json();
    return data;
  } catch (error) {
    console.error(`Failed to fetch therapist with id ${id}:`, error);
    return undefined; // Return undefined on error
  }
};
