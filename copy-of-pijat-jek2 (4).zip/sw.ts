// sw.ts (Service Worker)

// For type checking with Service Worker global scope and TypeScript
/// <reference lib="webworker" />
// declare let self: ServiceWorkerGlobalScope; // This line was removed

const CACHE_NAME = 'pijat-jek-cache-v1.1'; // Incremented version for updates
const URLS_TO_CACHE = [
  '/',
  '/index.html',
  // Key CDN assets (ensure these are stable URLs)
  'https://cdn.tailwindcss.com',
  'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css',
  'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js',
  // App icons (these will be in /public/icons/)
  '/icons/icon-192x192.png',
  '/icons/icon-512x512.png',
  '/icons/apple-touch-icon.png', // Ensure this exists
  '/metadata.json', // Usually small and static
  // Placeholder for Vite generated assets - a PWA plugin would manage this better
  // For now, we rely on the browser caching these based on HTTP headers,
  // or if their names were predictable and unhashed (not Vite's default).
];

self.addEventListener('install', (event) => {
  console.log('[ServiceWorker] Install event');
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => {
        console.log('[ServiceWorker] Opened cache:', CACHE_NAME);
        // Add all URLs to cache. If any request fails, installation fails.
        return cache.addAll(URLS_TO_CACHE)
          .then(() => console.log('[ServiceWorker] All specified URLs cached.'))
          .catch(error => {
            console.error('[ServiceWorker] Failed to cache one or more URLs during install:', error);
            // Optional: throw error to fail installation if critical assets missing
          });
      })
      .catch(err => {
        console.error('[ServiceWorker] Failed to open cache during install:', err);
      })
  );
});

self.addEventListener('fetch', (event) => {
  // We only want to intercept navigation and GET requests for caching strategy
  if (event.request.method !== 'GET') {
    return;
  }

  event.respondWith(
    caches.match(event.request)
      .then((cachedResponse) => {
        // Cache hit - return response
        if (cachedResponse) {
          // console.log('[ServiceWorker] Returning from cache:', event.request.url);
          return cachedResponse;
        }

        // Not in cache, fetch from network
        // console.log('[ServiceWorker] Fetching from network:', event.request.url);
        return fetch(event.request.clone()).then( // Clone request as it's a stream
          (networkResponse) => {
            // Check if we received a valid response
            if (!networkResponse || networkResponse.status !== 200) {
                // Do not cache errors or non-200 responses directly like this for all types
                // For 'basic' type (same-origin), we can cache.
                // For 'cors' type, also okay.
                // Opaque responses (cross-origin no-cors) should not be cached blindly as we can't check their status.
              if (networkResponse && (networkResponse.type === 'basic' || networkResponse.type === 'cors') && networkResponse.status === 200) {
                // Good response, clone it and cache it
                const responseToCache = networkResponse.clone(); // Clone response as it's a stream
                caches.open(CACHE_NAME)
                  .then((cache) => {
                    // Don't cache dynamic esm.sh responses in this basic setup
                    // as they are versioned and might have their own complex caching.
                    // Only cache if it's part of explicitly defined CDNs or local assets.
                    const isCachableCdn = URLS_TO_CACHE.some(url => event.request.url.startsWith(url));
                    if (!event.request.url.startsWith('https://esm.sh/') || isCachableCdn) {
                         cache.put(event.request, responseToCache);
                    }
                  });
              }
              return networkResponse;
            }

            // Valid response, cache it and return it
            const responseToCache = networkResponse.clone();
            caches.open(CACHE_NAME)
              .then((cache) => {
                 const isCachableCdn = URLS_TO_CACHE.some(url => event.request.url.startsWith(url));
                 if (!event.request.url.startsWith('https://esm.sh/') || isCachableCdn) {
                    cache.put(event.request, responseToCache);
                 }
              });
            return networkResponse;
          }
        ).catch(error => {
          console.error('[ServiceWorker] Fetch failed for:', event.request.url, error);
          // Fallback for navigation requests if offline and not in cache
          if (event.request.mode === 'navigate') {
            console.log('[ServiceWorker] Attempting to serve index.html as fallback for navigation.');
            return caches.match('/index.html');
          }
          // For other types of requests (e.g., images, scripts), let the browser handle the error.
        });
      })
  );
});

self.addEventListener('activate', (event) => {
  console.log('[ServiceWorker] Activate event');
  const cacheWhitelist = [CACHE_NAME]; // Keep the current cache
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cacheName) => {
          if (cacheWhitelist.indexOf(cacheName) === -1) {
            // Delete old caches
            console.log('[ServiceWorker] Deleting old cache:', cacheName);
            return caches.delete(cacheName);
          }
          return null; // Return null for caches that are not deleted
        })
      );
    }).then(() => {
      console.log('[ServiceWorker] Old caches cleaned up.');
      // Tell the active service worker to take control of the page immediately.
      return self.clients.claim();
    })
  );
});

// Optional: Listen for messages from client to skip waiting
self.addEventListener('message', (event) => {
  if (event.data && event.data.type === 'SKIP_WAITING') {
    console.log('[ServiceWorker] Skip waiting message received, activating new SW.');
    self.skipWaiting();
  }
});