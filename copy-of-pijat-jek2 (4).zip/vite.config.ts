import { defineConfig } from 'vite';
import { resolve } from 'path'; // Import resolve
import react from '@vitejs/plugin-react'; // Import the React plugin

// https://vitejs.dev/config/
export default defineConfig(({ mode }) => {
  // Capture the API_KEY from the system environment variables when Vite starts
  const systemEnvApiKey = process.env.API_KEY;

  return {
    plugins: [react()], // Enable the React plugin
    define: {
      // Make the API_KEY from the shell environment available 
      // as process.env.API_KEY in your client-side application code.
      'process.env.API_KEY': JSON.stringify(systemEnvApiKey || ''),
    },
    server: {
      port: 3000, // You can change the port if needed
      open: true,   // Automatically open the app in your browser
    },
    build: { // Add build configuration for PWA service worker
      rollupOptions: {
        input: {
          main: resolve(__dirname, 'index.html'),
          sw: resolve(__dirname, 'sw.ts'), // Service worker entry point
        },
        output: {
          entryFileNames: assetInfo => {
            // Output sw.js at the root, other JS assets in assets/
            return assetInfo.name === 'sw'
              ? 'sw.js'
              : 'assets/[name]-[hash].js';
          },
          // Ensure other chunks also go to assets
          chunkFileNames: 'assets/[name]-[hash].js',
          assetFileNames: 'assets/[name]-[hash].[ext]',
        }
      }
    }
  };
});