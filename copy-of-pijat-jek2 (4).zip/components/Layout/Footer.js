
export function renderFooter(container) {
  const footerHTML = `
    <footer class="bg-neutral-800 text-neutral-300 py-8 text-center">
      <div class="container mx-auto px-4">
        <p>2025 Pijat-jek hak cipta di lindungi oleh kopral jono </p>
        <p class="text-sm mt-1"> aplikasi aing kumaha aing </p>
        <p class="text-xs text-neutral-500 mt-3">slapped together by krishnaverse</p>
      </div>
    </footer>
  `;
  container.insertAdjacentHTML('beforeend', footerHTML);
}
