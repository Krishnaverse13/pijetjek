
import { APP_NAME, APP_ADMIN_ROUTES } from '../../constants.js';
import { HomeIcon, BriefcaseIcon, UserGroupIcon, ClipboardDocumentListIcon } from '../icons.js';


export function renderAdminLayout(container, pageRenderFunction, params) {
  const sidebarHTML = `
    <div class="w-64 bg-neutral-800 text-white flex flex-col p-4 space-y-2 shadow-lg fixed top-0 left-0 h-full z-30">
      <div class="text-2xl font-bold text-center py-4 mb-4 border-b border-neutral-700">
        ${APP_NAME}
      </div>
      <nav class="flex-grow">
        <a href="#${APP_ADMIN_ROUTES.DASHBOARD}" onclick="navigateTo('${APP_ADMIN_ROUTES.DASHBOARD}'); return false;" class="flex items-center px-4 py-3 text-neutral-100 hover:bg-neutral-700 transition-colors rounded-md ${window.location.hash === `#${APP_ADMIN_ROUTES.DASHBOARD}` ? 'bg-neutral-700 font-semibold' : ''}">
          ${HomeIcon('w-5 h-5 mr-3')} Dashboard
        </a>
        <a href="#${APP_ADMIN_ROUTES.THERAPISTS}" onclick="navigateTo('${APP_ADMIN_ROUTES.THERAPISTS}'); return false;" class="flex items-center px-4 py-3 text-neutral-100 hover:bg-neutral-700 transition-colors rounded-md ${window.location.hash === `#${APP_ADMIN_ROUTES.THERAPISTS}` ? 'bg-neutral-700 font-semibold' : ''}">
          ${BriefcaseIcon('w-5 h-5 mr-3')} Therapists
        </a>
        <a href="#${APP_ADMIN_ROUTES.USERS}" onclick="navigateTo('${APP_ADMIN_ROUTES.USERS}'); return false;" class="flex items-center px-4 py-3 text-neutral-100 hover:bg-neutral-700 transition-colors rounded-md ${window.location.hash === `#${APP_ADMIN_ROUTES.USERS}` ? 'bg-neutral-700 font-semibold' : ''}">
          ${UserGroupIcon('w-5 h-5 mr-3')} Users
        </a>
        <a href="#${APP_ADMIN_ROUTES.BOOKINGS}" onclick="navigateTo('${APP_ADMIN_ROUTES.BOOKINGS}'); return false;" class="flex items-center px-4 py-3 text-neutral-100 hover:bg-neutral-700 transition-colors rounded-md ${window.location.hash === `#${APP_ADMIN_ROUTES.BOOKINGS}` ? 'bg-neutral-700 font-semibold' : ''}">
          ${ClipboardDocumentListIcon('w-5 h-5 mr-3')} Bookings
        </a>
      </nav>
      <div class="mt-auto pt-4 border-t border-neutral-700">
         <p class="text-xs text-neutral-400 text-center">Admin Panel</p>
      </div>
    </div>
  `;

  const adminLayoutHTML = `
    <div class="flex h-screen">
      ${sidebarHTML}
      <div class="flex-1 flex flex-col overflow-hidden ml-64"> {/* ml-64 for sidebar width */}
        <header class="bg-white shadow-sm border-b border-neutral-200">
          <div class="container mx-auto px-6 py-4">
            <h1 class="text-xl font-semibold text-neutral-800">${APP_NAME} - Admin Panel</h1>
          </div>
        </header>
        <main class="flex-1 overflow-x-hidden overflow-y-auto bg-neutral-100 p-6" id="admin-content">
          <!-- Page content will be rendered here by pageRenderFunction -->
        </main>
         <footer class="bg-white border-t border-neutral-200 py-4 text-center text-sm text-neutral-500">
            <p>&copy; 2025 ${APP_NAME}</p>
        </footer>
      </div>
    </div>
  `;
  container.innerHTML = adminLayoutHTML;
  const adminContentContainer = container.querySelector('#admin-content');
  if (adminContentContainer && pageRenderFunction) {
    pageRenderFunction(adminContentContainer, params);
  } else if (!adminContentContainer) {
    console.error("Admin content container not found");
  }
}
