
import { APP_NAME, APP_ROUTES } from '../../constants.js';
import { UserCircleIcon } from '../icons.js';

export function renderHeader(container) {
  const headerHTML = `
    <header class="bg-primary shadow-md">
      <div class="container mx-auto px-4 py-4 flex justify-between items-center">
        <a href="#${APP_ROUTES.HOME}" onclick="navigateTo('${APP_ROUTES.HOME}'); return false;" class="text-2xl font-bold text-white hover:text-neutral-100 transition-colors">
          ${APP_NAME}
        </a>
        <nav class="flex items-center space-x-4">
          <a href="#${APP_ROUTES.HOME}" onclick="navigateTo('${APP_ROUTES.HOME}'); return false;" class="text-white hover:text-neutral-200 transition-colors">
            Beranda
          </a>
          <a href="#${APP_ROUTES.THERAPISTS}" onclick="navigateTo('${APP_ROUTES.THERAPISTS}'); return false;" class="text-white hover:text-neutral-200 transition-colors">
            Cari Therapist
          </a>
          <button class="text-white hover:text-neutral-200 transition-colors" aria-label="User Profile">
            ${UserCircleIcon('w-7 h-7')}
          </button>
        </nav>
      </div>
    </header>
  `;
  // Prepend header to keep it at the top
  container.insertAdjacentHTML('afterbegin', headerHTML);
}
