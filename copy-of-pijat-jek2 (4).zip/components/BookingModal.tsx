
import React, { useState, useEffect } from 'react';
import { Therapist, Service } from '../types';
import { XMarkIcon, CalendarDaysIcon, ClockIcon, CurrencyDollarIcon, UserIcon, TagIcon } from './icons/HeroIcons';

interface BookingModalProps {
  isOpen: boolean;
  onClose: () => void;
  therapist: Therapist | null;
  selectedService: Service | null;
  onConfirmBooking: (bookingDetails: { 
    date: string; 
    time: string; 
    notes?: string;
  }) => void; // This signature change will be handled in TherapistDetailPage
}

const BookingModal: React.FC<BookingModalProps> = ({ isOpen, onClose, therapist, selectedService, onConfirmBooking }) => {
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');
  const [notes, setNotes] = useState('');

  useEffect(() => {
    if (isOpen) {
      const today = new Date();
      const yyyy = today.getFullYear();
      const mm = String(today.getMonth() + 1).padStart(2, '0');
      const dd = String(today.getDate()).padStart(2, '0');
      setDate(`${yyyy}-${mm}-${dd}`);
      
      // Set default time to next hour or 09:00 if past typical working hours
      let defaultHour = today.getHours() + 1;
      if (defaultHour < 9) defaultHour = 9;
      if (defaultHour > 19) defaultHour = 9; // Reset to morning if late
      const defaultMinutes = "00";

      setTime(`${String(defaultHour).padStart(2, '0')}:${defaultMinutes}`);
      setNotes('');
    }
  }, [isOpen]);

  if (!isOpen || !therapist || !selectedService) {
    return null;
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!date || !time) {
        alert("Harap pilih tanggal dan waktu.");
        return;
    }
    // The actual payload for the API is constructed in TherapistDetailPage's handleConfirmBooking
    onConfirmBooking({ date, time, notes });
  };
  
  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', minimumFractionDigits: 0 }).format(price);
  };

  return (
    <div 
        className="fixed inset-0 bg-black bg-opacity-50 backdrop-blur-sm flex items-center justify-center p-4 z-50 transition-opacity duration-300"
        role="dialog"
        aria-modal="true"
        aria-labelledby="booking-modal-title"
    >
      <div className="bg-white rounded-lg shadow-xl p-6 w-full max-w-lg max-h-[90vh] overflow-y-auto">
        <div className="flex justify-between items-center mb-6">
          <h2 id="booking-modal-title" className="text-2xl font-semibold text-neutral-800">Konfirmasi Pemesanan</h2>
          <button 
            onClick={onClose} 
            className="text-neutral-500 hover:text-neutral-700 transition-colors"
            aria-label="Close booking modal"
          >
            <XMarkIcon className="w-7 h-7" />
          </button>
        </div>

        <div className="mb-6 p-4 bg-primary/5 rounded-md border border-primary/20">
            <div className="flex items-center mb-2">
                <UserIcon className="w-5 h-5 mr-2 text-primary"/>
                <p className="text-lg font-medium text-neutral-700">{therapist.name}</p>
            </div>
            <div className="flex items-center">
                <TagIcon className="w-5 h-5 mr-2 text-primary"/>
                <p className="text-lg font-medium text-neutral-700">{selectedService.name}</p>
            </div>
            <div className="mt-2 flex items-center text-sm text-neutral-600">
                <CurrencyDollarIcon className="w-4 h-4 mr-1 text-green-600"/>
                <span>Total: {formatPrice(selectedService.price)}</span>
            </div>
        </div>

        <form onSubmit={handleSubmit}>
          <div className="mb-4">
            <label htmlFor="booking-date" className="block text-sm font-medium text-neutral-700 mb-1">
              Pilih Tanggal
            </label>
            <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <CalendarDaysIcon className="h-5 w-5 text-neutral-400" />
                </div>
                <input
                type="date"
                id="booking-date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                min={new Date().toISOString().split('T')[0]} 
                required
                className="block w-full pl-10 pr-3 py-2 border border-neutral-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary sm:text-sm"
                />
            </div>
          </div>

          <div className="mb-4">
            <label htmlFor="booking-time" className="block text-sm font-medium text-neutral-700 mb-1">
              Pilih Waktu
            </label>
            <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <ClockIcon className="h-5 w-5 text-neutral-400" />
                </div>
                <input
                type="time"
                id="booking-time"
                value={time}
                onChange={(e) => setTime(e.target.value)}
                required
                className="block w-full pl-10 pr-3 py-2 border border-neutral-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary sm:text-sm"
                />
            </div>
          </div>

          <div className="mb-6">
            <label htmlFor="booking-notes" className="block text-sm font-medium text-neutral-700 mb-1">
              Catatan Tambahan (Opsional)
            </label>
            <textarea
              id="booking-notes"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={3}
              placeholder="cth: Fokus pada area punggung bawah, alergi minyak tertentu."
              className="block w-full pr-3 py-2 border border-neutral-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary sm:text-sm"
            />
          </div>

          <div className="flex justify-end space-x-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-sm font-medium text-neutral-700 bg-neutral-100 hover:bg-neutral-200 border border-neutral-300 rounded-lg transition-colors"
            >
              Batal
            </button>
            <button
              type="submit"
              className="px-6 py-2 text-sm font-medium text-white bg-secondary hover:bg-primary rounded-lg transition-colors"
            >
              Ajukan Pemesanan
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default BookingModal;
