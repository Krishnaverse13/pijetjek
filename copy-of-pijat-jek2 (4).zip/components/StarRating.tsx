import React from 'react';
import { StarIcon as StarIconSolid } from './icons/HeroIcons'; // Assuming solid version for filled stars
import { StarIcon as StarIconOutline } from './icons/HeroIconsOutline'; // Assuming outline version for empty stars

interface StarRatingProps {
  rating: number;
  maxStars?: number;
  starClassName?: string;
}

const StarRating: React.FC<StarRatingProps> = ({ rating, maxStars = 5, starClassName = "w-5 h-5 text-yellow-400" }) => {
  const fullStars = Math.floor(rating);
  const halfStar = rating % 1 !== 0; // Not implementing half star visually yet, count as full for simplicity
  const emptyStars = maxStars - fullStars - (halfStar ? 1 : 0);

  return (
    <div className="flex items-center" aria-label={`Rating: ${rating} out of ${maxStars} stars`}>
      {[...Array(fullStars)].map((_, i) => (
        <StarIconSolid key={`full-${i}`} className={starClassName} aria-hidden="true" />
      ))}
      {/* Placeholder for half star if needed in future */}
      {/* {halfStar && <StarIconHalf key="half" className={starClassName} />} */}
      {[...Array(Math.max(0, emptyStars + (halfStar ? 1 : 0) - (halfStar ? 1 : 0)))].map((_, i) => (
         // Using outline for empty for now, can use a specific empty star icon if available
        <StarIconOutline key={`empty-${i}`} className={`${starClassName} text-neutral-300`} aria-hidden="true" />
      ))}
    </div>
  );
};

export default StarRating;