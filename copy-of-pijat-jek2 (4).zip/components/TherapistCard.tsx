import React from 'react';
import { Link } from 'react-router-dom';
import { Therapist } from '../types';
import StarRating from './StarRating'; // Assuming StarRating component exists
import { MapPinIcon, SparklesIcon } from './icons/HeroIcons';
import { APP_ROUTES } from '../constants';


interface TherapistCardProps {
  therapist: Therapist;
}

const TherapistCard: React.FC<TherapistCardProps> = ({ therapist }) => {
  const availabilityColor = therapist.availability === 'Tersedia Sekarang' ? 'text-green-600 bg-green-100' : 
                            therapist.availability === 'Segera Tersedia' ? 'text-yellow-600 bg-yellow-100' : 'text-gray-500 bg-gray-100';

  return (
    <Link 
      to={APP_ROUTES.THERAPIST_DETAIL(therapist.id)} 
      className="block bg-white rounded-lg shadow-lg hover:shadow-xl transition-shadow duration-300 overflow-hidden group"
      aria-label={`View details for ${therapist.name}`}
    >
      <div className="relative">
        <img 
          src={therapist.imageUrl} 
          alt={therapist.name} 
          className="w-full h-48 object-cover transition-transform duration-300 group-hover:scale-105" 
          loading="lazy"
        />
        <div className={`absolute top-2 right-2 px-2 py-1 text-xs font-semibold rounded-full ${availabilityColor} flex items-center`}>
          <SparklesIcon className="w-3 h-3 mr-1"/>
          {therapist.availability}
        </div>
      </div>
      <div className="p-5">
        <h3 className="text-xl font-semibold text-neutral-800 mb-1 truncate group-hover:text-primary">{therapist.name}</h3>
        <div className="flex items-center mb-2">
          <StarRating rating={therapist.rating} />
          <span className="text-xs text-neutral-500 ml-2">({therapist.reviewCount} reviews)</span>
        </div>
        <div className="text-sm text-neutral-600 mb-3">
          {therapist.specialties.slice(0, 2).join(', ')}
          {therapist.specialties.length > 2 ? '...' : ''}
        </div>
        <div className="flex items-center text-xs text-neutral-500 mb-3">
          <MapPinIcon className="w-4 h-4 mr-1 text-primary" />
          <span>{therapist.location}</span>
        </div>
        <p className="text-sm text-neutral-700 leading-relaxed line-clamp-2 mb-4">
          {therapist.bio}
        </p>
        <button 
            className="w-full bg-primary text-white py-2 px-4 rounded-md hover:bg-secondary transition-colors text-sm font-medium"
            aria-hidden="true" // The link itself is the primary action
            tabIndex={-1} // The link itself is focusable
        >
          Lihat Detail & Layanan
        </button>
      </div>
    </Link>
  );
};

export default TherapistCard;