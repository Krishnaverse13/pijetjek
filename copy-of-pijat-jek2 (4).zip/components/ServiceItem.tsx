import React from 'react';
import { Service } from '../types';
import { ClockIcon, CurrencyDollarIcon } from './icons/HeroIcons'; // Assuming these icons exist

interface ServiceItemProps {
  service: Service;
  isSelected: boolean;
  onSelect: (service: Service) => void;
}

const ServiceItem: React.FC<ServiceItemProps> = ({ service, isSelected, onSelect }) => {
  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', minimumFractionDigits: 0 }).format(price);
  };

  return (
    <button
      onClick={() => onSelect(service)}
      className={`w-full p-4 border rounded-lg text-left transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-primary
                  ${isSelected ? 'bg-primary/10 border-primary shadow-md' : 'bg-white hover:bg-neutral-50 border-neutral-200'}`}
      aria-pressed={isSelected}
      aria-label={`Select service: ${service.name}`}
    >
      <div className="flex justify-between items-start">
        <div>
          <h3 className={`text-lg font-semibold ${isSelected ? 'text-primary' : 'text-neutral-800'}`}>{service.name}</h3>
          <p className="text-sm text-neutral-600 mt-1">{service.description}</p>
        </div>
        {isSelected && (
          <div className="flex-shrink-0 ml-4 mt-1 text-primary">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="w-6 h-6">
              <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
            </svg>
          </div>
        )}
      </div>
      <div className="mt-3 flex items-center justify-between text-sm text-neutral-700">
        <div className="flex items-center">
          <CurrencyDollarIcon className="w-4 h-4 mr-1 text-green-600" />
          <span>{formatPrice(service.price)}</span>
        </div>
        {service.durationMinutes > 0 && (
            <div className="flex items-center">
            <ClockIcon className="w-4 h-4 mr-1 text-blue-600" />
            <span>{service.durationMinutes} menit</span>
            </div>
        )}
      </div>
    </button>
  );
};

export default ServiceItem;