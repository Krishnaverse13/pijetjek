import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { APP_NAME, APP_ADMIN_ROUTES } from '../../constants';
import { HomeIcon, BriefcaseIcon, UserGroupIcon, ClipboardDocumentListIcon, CogIcon } from '../icons/HeroIcons'; // Assuming icons

const AdminSidebar: React.FC = () => {
  const location = useLocation();

  const navItems = [
    { name: 'Dashboard', route: APP_ADMIN_ROUTES.DASHBOARD, icon: HomeIcon },
    { name: 'Therapists', route: APP_ADMIN_ROUTES.THERAPISTS, icon: BriefcaseIcon },
    { name: 'Users', route: APP_ADMIN_ROUTES.USERS, icon: UserGroupIcon },
    { name: 'Bookings', route: APP_ADMIN_ROUTES.BOOKINGS, icon: ClipboardDocumentListIcon },
    // { name: 'Settings', route: '/admin/settings', icon: CogIcon }, // Example for future
  ];

  // Normalize paths for comparison, especially for nested admin routes
  const normalizePath = (path: string) => {
    // If base admin route is /admin, and current route is /admin/therapists, location.pathname is /admin/therapists
    // APP_ADMIN_ROUTES.THERAPISTS is /admin/therapists
    // This direct comparison should work fine for HashRouter if full paths are used in APP_ADMIN_ROUTES
    return path;
  };
  
  const isActive = (route: string) => {
    const currentPath = normalizePath(location.pathname);
    const itemPath = normalizePath(route);
    if (itemPath === APP_ADMIN_ROUTES.DASHBOARD) { // Special case for dashboard matching base /admin or /admin/
        return currentPath === itemPath || currentPath === itemPath + '/';
    }
    return currentPath.startsWith(itemPath);
  };


  return (
    <div className="w-64 bg-neutral-800 text-white flex flex-col p-4 space-y-2 shadow-lg fixed top-0 left-0 h-full z-30">
      <Link to={APP_ADMIN_ROUTES.DASHBOARD} className="text-2xl font-bold text-center py-4 mb-4 border-b border-neutral-700 hover:text-primary transition-colors">
        {APP_NAME}
      </Link>
      <nav className="flex-grow">
        {navItems.map(item => {
          const IconComponent = item.icon;
          return (
            <Link
              key={item.name}
              to={item.route}
              className={`flex items-center px-4 py-3 text-neutral-100 hover:bg-neutral-700 hover:text-white transition-colors rounded-md
                          ${isActive(item.route) ? 'bg-primary text-white font-semibold shadow-inner' : 'text-neutral-300'}`}
              aria-current={isActive(item.route) ? 'page' : undefined}
            >
              <IconComponent className="w-5 h-5 mr-3 flex-shrink-0" />
              {item.name}
            </Link>
          );
        })}
      </nav>
      <div className="mt-auto pt-4 border-t border-neutral-700">
        <p className="text-xs text-neutral-400 text-center">&copy; {new Date().getFullYear()} {APP_NAME} Admin</p>
      </div>
    </div>
  );
};

export default AdminSidebar;