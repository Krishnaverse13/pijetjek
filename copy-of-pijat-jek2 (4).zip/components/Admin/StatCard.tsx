import React from 'react';

interface StatCardProps {
  title: string;
  value: string | number;
  icon: React.ReactNode;
  colorClass?: string; // e.g., 'bg-blue-500'
  description?: string;
  linkTo?: string; // Optional link for the card
}

const StatCard: React.FC<StatCardProps> = ({ title, value, icon, colorClass = 'bg-primary', description, linkTo }) => {
  const cardContent = (
    <>
      <div className={`p-3 rounded-full text-white ${colorClass} mr-4 inline-flex items-center justify-center`}>
        {icon}
      </div>
      <div>
        <p className="text-sm text-neutral-500 font-medium">{title}</p>
        <p className="text-2xl font-semibold text-neutral-800">{value}</p>
        {description && <p className="text-xs text-neutral-400 mt-1">{description}</p>}
      </div>
    </>
  );

  if (linkTo) {
    return (
      <a href={linkTo} className="bg-white p-5 rounded-lg shadow-lg flex items-center hover:shadow-xl transition-shadow transform hover:-translate-y-1">
        {cardContent}
      </a>
    );
  }

  return (
    <div className="bg-white p-5 rounded-lg shadow-lg flex items-center">
      {cardContent}
    </div>
  );
};

export default StatCard;