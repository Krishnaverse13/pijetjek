import React, { useEffect, useRef } from 'react';
import { Therapist } from '../types';
// Import Leaflet and its CSS. Ensure Leaflet is installed (e.g., npm install leaflet @types/leaflet)
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';

// Fix for default Leaflet marker icon issue with bundlers like Webpack/Vite
import iconRetinaUrl from 'leaflet/dist/images/marker-icon-2x.png';
import iconUrl from 'leaflet/dist/images/marker-icon.png';
import shadowUrl from 'leaflet/dist/images/marker-shadow.png';

delete (L.Icon.Default.prototype as any)._getIconUrl; // неприятен хак (unpleasant hack)

L.Icon.Default.mergeOptions({
  iconRetinaUrl,
  iconUrl,
  shadowUrl,
});


interface MapDisplayProps {
  therapists: Therapist[];
  selectedTherapistId?: string; // Optional: to highlight a therapist
}

const MapDisplay: React.FC<MapDisplayProps> = ({ therapists, selectedTherapistId }) => {
  const mapRef = useRef<L.Map | null>(null);
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const markersRef = useRef<L.Marker[]>([]);

  // Default center: Jakarta
  const DEFAULT_CENTER: L.LatLngTuple = [-6.2088, 106.8456];
  const DEFAULT_ZOOM = 10;

  useEffect(() => {
    if (mapContainerRef.current && !mapRef.current) {
      const map = L.map(mapContainerRef.current).setView(DEFAULT_CENTER, DEFAULT_ZOOM);
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
      }).addTo(map);
      mapRef.current = map;
    }

    // Clear existing markers
    markersRef.current.forEach(marker => marker.remove());
    markersRef.current = [];

    if (mapRef.current && therapists.length > 0) {
      const validTherapists = therapists.filter(t => typeof t.latitude === 'number' && typeof t.longitude === 'number');
      
      validTherapists.forEach(therapist => {
        const marker = L.marker([therapist.latitude, therapist.longitude])
          .addTo(mapRef.current!)
          .bindPopup(`<b>${therapist.name}</b><br>${therapist.location}<br><a href="#/therapists/${therapist.id}">View Details</a>`);
        markersRef.current.push(marker);

        if (therapist.id === selectedTherapistId) {
          marker.openPopup();
          mapRef.current?.setView([therapist.latitude, therapist.longitude], 13);
        }
      });

      // Adjust map bounds if multiple therapists
      if (validTherapists.length > 1) {
        const group = L.featureGroup(markersRef.current);
        mapRef.current.fitBounds(group.getBounds().pad(0.3));
      } else if (validTherapists.length === 1) {
         mapRef.current.setView([validTherapists[0].latitude, validTherapists[0].longitude], 13);
      } else {
        mapRef.current.setView(DEFAULT_CENTER, DEFAULT_ZOOM);
      }
    } else if (mapRef.current) {
        mapRef.current.setView(DEFAULT_CENTER, DEFAULT_ZOOM);
    }
    
    return () => {
        // Cleanup markers on component unmount or before therapists update
        // markersRef.current.forEach(marker => marker.remove());
        // No need to destroy map here if it should persist across re-renders of parent
    };
  }, [therapists, selectedTherapistId]);

  return (
    <div 
        ref={mapContainerRef} 
        className="h-[400px] w-full rounded-lg shadow-md overflow-hidden mb-8 bg-neutral-200"
        aria-label="Map displaying therapist locations"
    >
        {/* Map will be initialized here */}
    </div>
  );
};

export default MapDisplay;