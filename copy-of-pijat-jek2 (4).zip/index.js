
import { APP_NAME, APP_ROUTES, APP_ADMIN_ROUTES } from './constants.js';
import { renderHeader } from './components/Layout/Header.js';
import { renderFooter } from './components/Layout/Footer.js';
import { renderAdminLayout } from './components/Layout/AdminLayout.js';

// Page Renderers (Import stubs or actual implementations)
import { renderHomePage } from './pages/HomePage.js';
import { renderTherapistListPage } from './pages/TherapistListPage.js';
import { renderTherapistDetailPage } from './pages/TherapistDetailPage.js';
import { renderNotFoundPage } from './pages/NotFoundPage.js';

import { renderAdminDashboardPage } from './pages/Admin/AdminDashboardPage.js';
import { renderAdminTherapistManagementPage } from './pages/Admin/AdminTherapistManagementPage.js';
import { renderAdminUserManagementPage } from './pages/Admin/AdminUserManagementPage.js';
import { renderAdminBookingManagementPage } from './pages/Admin/AdminBookingManagementPage.js';


const root = document.getElementById('root');
let currentPage = '';

// --- Navigation ---
function navigateTo(path) {
  if (window.location.hash === `#${path}`) {
    // console.log("Already on path:", path);
    // handleRouteChange(); // Could force a re-render
    return;
  }
  window.location.hash = path;
}
// Make navigateTo globally accessible for inline event handlers in HTML strings
window.navigateTo = navigateTo;


const routes = {
  [APP_ROUTES.HOME]: { render: renderHomePage, layout: 'user' },
  [APP_ROUTES.THERAPISTS]: { render: renderTherapistListPage, layout: 'user' },
  [APP_ROUTES.THERAPIST_DETAIL_PARAM]: { render: renderTherapistDetailPage, layout: 'user', isParameterized: true, paramName: 'therapistId' },
  // Admin routes
  [APP_ADMIN_ROUTES.DASHBOARD]: { render: renderAdminDashboardPage, layout: 'admin' },
  [APP_ADMIN_ROUTES.THERAPISTS]: { render: renderAdminTherapistManagementPage, layout: 'admin' },
  [APP_ADMIN_ROUTES.USERS]: { render: renderAdminUserManagementPage, layout: 'admin' },
  [APP_ADMIN_ROUTES.BOOKINGS]: { render: renderAdminBookingManagementPage, layout: 'admin' },
};

function handleRouteChange() {
  if (!root) {
    console.error("Root element not found");
    return;
  }
  const hash = window.location.hash.slice(1) || '/';
  currentPage = hash;
  root.innerHTML = ''; // Clear previous content

  let matchedRouteConfig = null;
  let params = {};

  for (const routePath in routes) {
    const routeConfig = routes[routePath];
    if (routeConfig.isParameterized) {
      // Example: /therapists/:therapistId
      // Turns into regex: /^\/therapists\/([^/]+)$/
      const paramKey = routeConfig.paramName || 'id'; // e.g., 'therapistId'
      const regexPath = `^${routePath.replace(/:\w+/, '([^/]+)')}$`;
      const routeMatcher = new RegExp(regexPath);
      const match = hash.match(routeMatcher);

      if (match) {
        params[paramKey] = match[1]; // The captured group
        matchedRouteConfig = routeConfig;
        break;
      }
    } else if (hash === routePath) {
      matchedRouteConfig = routeConfig;
      break;
    }
  }
  
  if (matchedRouteConfig) {
    if (matchedRouteConfig.layout === 'user') {
      root.className = 'flex flex-col min-h-screen bg-neutral-100';
      renderHeader(root);
      const main = document.createElement('main');
      main.className = 'flex-grow container mx-auto px-4 py-8';
      root.appendChild(main);
      matchedRouteConfig.render(main, params);
      renderFooter(root);
    } else if (matchedRouteConfig.layout === 'admin') {
      root.className = 'h-screen bg-neutral-100'; // Admin layout takes full screen
      renderAdminLayout(root, matchedRouteConfig.render, params);
    }
  } else {
    // Fallback for unmatched routes - default to user layout for 404
    root.className = 'flex flex-col min-h-screen bg-neutral-100';
    renderHeader(root);
    const main = document.createElement('main');
    main.className = 'flex-grow container mx-auto px-4 py-8';
    root.appendChild(main);
    renderNotFoundPage(main); // renderNotFoundPage doesn't need params
    renderFooter(root);
  }
}

// Initial setup
document.addEventListener('DOMContentLoaded', () => {
  if (!root) {
    console.error("Root element not found on DOMContentLoaded. App will not initialize.");
    return;
  }
  handleRouteChange(); // Handle initial route
  window.addEventListener('hashchange', handleRouteChange); // Handle route changes

  // Service Worker
  if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
      navigator.serviceWorker.register('/sw.js') // Path relative to origin
        .then(registration => {
          console.log('ServiceWorker registration successful with scope: ', registration.scope);
        })
        .catch(error => {
          console.log('ServiceWorker registration failed: ', error);
        });
    });
  }
});
