
import React, { useState, useEffect } from 'react';
import { fetchAdminUsers, updateUserStatus } from '../../services/adminService';
import { AdminUser, AdminUserStatus } from '../../types';
import { MagnifyingGlassIcon, UserCircleIcon } from '../../components/icons/HeroIcons';
import LoadingSpinner from '../../components/LoadingSpinner';

const AdminUserManagementPage: React.FC = () => {
  const [users, setUsers] = useState<AdminUser[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    const loadData = async () => {
      setIsLoading(true);
      setError(null);
      try {
        const data = await fetchAdminUsers();
        setUsers(data);
      } catch (err) {
        setError("Gagal memuat data pengguna.");
        console.error(err);
      }
      setIsLoading(false);
    };
    loadData();
  }, []);

  const getStatusColor = (status: AdminUserStatus) => {
    return status === 'Aktif' ? 'text-green-600 bg-green-100' : 'text-red-600 bg-red-100';
  };

  const handleStatusToggle = async (userId: string, currentStatus: AdminUserStatus) => {
    const newStatus = currentStatus === 'Aktif' ? 'Ditangguhkan' : 'Aktif';
    const originalUsers = [...users];
    // Optimistic update
    setUsers(prevUsers => 
      prevUsers.map(u => 
        u.id === userId ? { ...u, status: newStatus } : u
      )
    );

    const updatedUser = await updateUserStatus(userId, newStatus);
    if (updatedUser) {
      setUsers(prevUsers => 
        prevUsers.map(u => 
          u.id === userId ? updatedUser : u
        )
      );
    } else {
      setUsers(originalUsers);
      alert(`Gagal memperbarui status untuk pengguna ${userId}.`);
    }
  };
  
  const filteredUsers = users.filter(user => 
    user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.status.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (isLoading) {
    return <div className="flex justify-center items-center h-64"><LoadingSpinner text="Memuat data pengguna..." /></div>;
  }
  if (error) {
    return <div className="text-center py-10 text-red-600">{error}</div>;
  }

  return (
    <div className="bg-white p-6 rounded-lg shadow-lg">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-semibold text-neutral-800">Manajemen Pengguna (Klien)</h2>
      </div>

       <div className="mb-4">
        <div className="relative">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <MagnifyingGlassIcon className="h-5 w-5 text-neutral-400" aria-hidden="true" />
          </div>
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Cari pengguna (nama, email, status)..."
            className="block w-full pl-10 pr-3 py-2 border border-neutral-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary sm:text-sm"
          />
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-neutral-200">
          <thead className="bg-neutral-50">
            <tr>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Pengguna</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Email</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Tgl Bergabung</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Total Pesanan</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Status</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Aksi</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-neutral-200">
            {filteredUsers.map((user) => (
              <tr key={user.id} className="hover:bg-neutral-50 transition-colors">
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center">
                    <UserCircleIcon className="w-10 h-10 text-neutral-400 mr-3" />
                    <div className="text-sm font-medium text-neutral-900">{user.name}</div>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-500">{user.email}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-500">{new Date(user.joinDate).toLocaleDateString('id-ID')}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-500 text-center">{user.totalBookings}</td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusColor(user.status)}`}>
                    {user.status}
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                  <button 
                    onClick={() => handleStatusToggle(user.id, user.status)}
                    className={`text-xs py-1 px-2 rounded-md ${user.status === 'Aktif' ? 'bg-red-100 text-red-700 hover:bg-red-200' : 'bg-green-100 text-green-700 hover:bg-green-200'}`}
                    aria-label={`${user.status === 'Aktif' ? 'Tangguhkan' : 'Aktifkan'} ${user.name}`}
                  >
                    {user.status === 'Aktif' ? 'Tangguhkan' : 'Aktifkan'}
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {filteredUsers.length === 0 && (
          <p className="text-center text-neutral-500 py-8">Tidak ada pengguna yang cocok dengan pencarian Anda.</p>
        )}
      </div>
    </div>
  );
};

export default AdminUserManagementPage;
