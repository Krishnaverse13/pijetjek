
import React, { useState, useEffect } from 'react';
import { fetchAdminTherapists, updateTherapistStatus } from '../../services/adminService';
import { Therapist, TherapistAdminStatus } from '../../types';
import { ShieldCheckIcon, MagnifyingGlassIcon, UserCircleIcon } from '../../components/icons/HeroIcons'; // Added UserCircleIcon
import LoadingSpinner from '../../components/LoadingSpinner';

const AdminTherapistManagementPage: React.FC = () => {
  const [therapists, setTherapists] = useState<Therapist[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    const loadData = async () => {
      setIsLoading(true);
      setError(null);
      try {
        const data = await fetchAdminTherapists();
        setTherapists(data);
      } catch (err) {
        setError("Gagal memuat data terapis.");
        console.error(err);
      }
      setIsLoading(false);
    };
    loadData();
  }, []);

  const getStatusColor = (status?: TherapistAdminStatus) => {
    switch (status) {
      case 'Disetujui': return 'text-green-600 bg-green-100';
      case 'Menunggu Tinjauan': return 'text-amber-600 bg-amber-100';
      case 'Ditolak': return 'text-red-600 bg-red-100';
      default: return 'text-neutral-500 bg-neutral-100';
    }
  };

  const handleStatusChange = async (therapistId: string, newStatus: TherapistAdminStatus) => {
    const originalTherapists = [...therapists];
    // Optimistic update
    setTherapists(prevTherapists => 
      prevTherapists.map(t => 
        t.id === therapistId ? { ...t, adminStatus: newStatus } : t
      )
    );

    const updatedTherapist = await updateTherapistStatus(therapistId, newStatus);
    if (updatedTherapist) {
      // Update with server response (might have other changes)
      setTherapists(prevTherapists => 
        prevTherapists.map(t => 
          t.id === therapistId ? updatedTherapist : t
        )
      );
    } else {
      // Revert on failure
      setTherapists(originalTherapists);
      alert(`Gagal memperbarui status untuk terapis ${therapistId}.`);
    }
  };

  const filteredTherapists = therapists.filter(therapist => {
    const lowerSearchTerm = searchTerm.toLowerCase();
    return (
      therapist.name.toLowerCase().includes(lowerSearchTerm) ||
      (therapist.email && therapist.email.toLowerCase().includes(lowerSearchTerm)) ||
      therapist.location.toLowerCase().includes(lowerSearchTerm) ||
      (therapist.adminStatus && therapist.adminStatus.toLowerCase().includes(lowerSearchTerm))
    );
  });
  
  const availableAdminStatuses: TherapistAdminStatus[] = ['Disetujui', 'Menunggu Tinjauan', 'Ditolak'];

  if (isLoading) {
    return <div className="flex justify-center items-center h-64"><LoadingSpinner text="Memuat data terapis..." /></div>;
  }
  if (error) {
    return <div className="text-center py-10 text-red-600">{error}</div>;
  }

  return (
    <div className="bg-white p-6 rounded-lg shadow-lg">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-semibold text-neutral-800">Manajemen Terapis</h2>
        <button className="bg-primary hover:bg-secondary text-white font-semibold py-2 px-4 rounded-lg transition-colors text-sm">
          Tambah Terapis Baru (Belum aktif)
        </button>
      </div>
      
      <div className="mb-4">
        <div className="relative">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <MagnifyingGlassIcon className="h-5 w-5 text-neutral-400" aria-hidden="true" />
          </div>
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Cari terapis (nama, email, lokasi, status)..."
            className="block w-full pl-10 pr-3 py-2 border border-neutral-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary sm:text-sm"
          />
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-neutral-200">
          <thead className="bg-neutral-50">
            <tr>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Nama</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Email</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Lokasi</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Rating</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Status Admin</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Aksi</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-neutral-200">
            {filteredTherapists.map((therapist) => (
              <tr key={therapist.id} className="hover:bg-neutral-50 transition-colors">
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center">
                    <div className="flex-shrink-0 h-10 w-10">
                      <img className="h-10 w-10 rounded-full object-cover" src={therapist.imageUrl || `https://ui-avatars.com/api/?name=${encodeURIComponent(therapist.name)}&background=06b6d4&color=fff`} alt={therapist.name} />
                    </div>
                    <div className="ml-4">
                      <div className="text-sm font-medium text-neutral-900">{therapist.name}</div>
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-500">{therapist.email || 'N/A'}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-500">{therapist.location}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-500">{therapist.rating.toFixed(1)} ({therapist.reviewCount})</td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusColor(therapist.adminStatus)}`}>
                    <ShieldCheckIcon className="w-3 h-3 mr-1 mt-0.5" />
                    {therapist.adminStatus || 'Belum Ditinjau'}
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                  <select 
                    value={therapist.adminStatus || ''} 
                    onChange={(e) => handleStatusChange(therapist.id, e.target.value as TherapistAdminStatus)}
                    className="text-xs border-neutral-300 rounded-md focus:ring-primary focus:border-primary p-1 mr-2"
                    aria-label={`Ubah status untuk ${therapist.name}`}
                  >
                    <option value="" disabled>Pilih Status</option>
                    {availableAdminStatuses.map(status => (
                       <option key={status} value={status}>{status}</option>
                    ))}
                  </select>
                  <a href={`#/therapists/${therapist.id}`} target="_blank" rel="noopener noreferrer" className="text-primary hover:text-secondary text-xs">Lihat</a>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {filteredTherapists.length === 0 && (
          <p className="text-center text-neutral-500 py-8">Tidak ada terapis yang cocok dengan pencarian Anda.</p>
        )}
      </div>
    </div>
  );
};

export default AdminTherapistManagementPage;
