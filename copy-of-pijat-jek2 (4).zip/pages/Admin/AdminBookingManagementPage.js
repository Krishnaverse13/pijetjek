
export function renderAdminBookingManagementPage(container) {
  container.innerHTML = `
    <h2 class="text-2xl font-semibold text-neutral-800 mb-6">Booking Management</h2>
    <p>This page is not yet implemented in vanilla JS.</p>
    <p>It will allow admins to view and manage bookings.</p>
  `;
}
