
export function renderAdminTherapistManagementPage(container) {
  container.innerHTML = `
    <h2 class="text-2xl font-semibold text-neutral-800 mb-6">Therapist Management</h2>
    <p>This page is not yet implemented in vanilla JS.</p>
    <p>It will allow admins to view, approve, and manage therapists.</p>
  `;
}
