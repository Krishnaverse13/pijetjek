
import React, { useState, useEffect } from 'react';
import StatCard from '../../components/Admin/StatCard';
import { APP_ADMIN_ROUTES } from '../../constants';
import { BriefcaseIcon, UserGroupIcon, ClipboardDocumentListIcon, CurrencyDollarIcon } from '../../components/icons/HeroIcons';
import { fetchAdminTherapists, fetchAdminUsers, fetchAdminBookings } from '../../services/adminService';
import { AdminBooking } from '../../types';
import LoadingSpinner from '../../components/LoadingSpinner';

const AdminDashboardPage: React.FC = () => {
  const [totalTherapists, setTotalTherapists] = useState(0);
  const [totalUsers, setTotalUsers] = useState(0);
  const [totalBookings, setTotalBookings] = useState(0);
  const [totalRevenue, setTotalRevenue] = useState(0);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      setIsLoading(true);
      try {
        const [therapists, users, bookings] = await Promise.all([
          fetchAdminTherapists(),
          fetchAdminUsers(),
          fetchAdminBookings()
        ]);
        setTotalTherapists(therapists.length);
        setTotalUsers(users.length);
        setTotalBookings(bookings.length);

        const revenue = bookings.reduce((sum: number, booking: AdminBooking) => {
          return booking.status === 'Selesai' ? sum + booking.price : sum;
        }, 0);
        setTotalRevenue(revenue);

      } catch (error) {
        console.error("Failed to load dashboard data:", error);
        // Optionally set an error state to display to the user
      }
      setIsLoading(false);
    };
    fetchData();
  }, []);

  const formattedRevenue = new Intl.NumberFormat('id-ID', {
    style: 'currency',
    currency: 'IDR',
    minimumFractionDigits: 0,
  }).format(totalRevenue);

  if (isLoading) {
    return <div className="flex justify-center items-center h-64"><LoadingSpinner text="Memuat dasbor..." /></div>;
  }

  return (
    <div>
      <h2 className="text-2xl font-semibold text-neutral-800 mb-6">Ringkasan Dasbor</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <StatCard 
          title="Total Terapis" 
          value={totalTherapists} 
          icon={<BriefcaseIcon className="w-6 h-6" />} 
          colorClass="bg-cyan-500"
          linkTo={`#${APP_ADMIN_ROUTES.THERAPISTS}`}
        />
        <StatCard 
          title="Total Pengguna" 
          value={totalUsers} 
          icon={<UserGroupIcon className="w-6 h-6" />}
          colorClass="bg-amber-500"
          linkTo={`#${APP_ADMIN_ROUTES.USERS}`}
        />
        <StatCard 
          title="Total Pemesanan" 
          value={totalBookings} 
          icon={<ClipboardDocumentListIcon className="w-6 h-6" />}
          colorClass="bg-green-500"
          linkTo={`#${APP_ADMIN_ROUTES.BOOKINGS}`}
        />
        <StatCard 
          title="Total Pendapatan (Selesai)" 
          value={formattedRevenue} 
          icon={<CurrencyDollarIcon className="w-6 h-6" />}
          colorClass="bg-purple-500"
          description="Dari pemesanan yang selesai"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-lg shadow-lg">
          <h3 className="text-lg font-semibold text-neutral-700 mb-4">Aktivitas Terkini (Placeholder)</h3>
          <ul className="space-y-3">
            <li className="text-sm text-neutral-600">Terapis baru "Joko P." mendaftar - menunggu tinjauan.</li>
            <li className="text-sm text-neutral-600">Pemesanan #B007 dikonfirmasi untuk "Siti Aminah".</li>
            <li className="text-sm text-neutral-600">Pengguna "Maria L." menyelesaikan pemesanan ke-3 nya.</li>
            {/* In a real app, this would be dynamic data */}
          </ul>
        </div>
        <div className="bg-white p-6 rounded-lg shadow-lg">
          <h3 className="text-lg font-semibold text-neutral-700 mb-4">Tautan Cepat</h3>
           <div className="space-y-2">
            <a href={`#${APP_ADMIN_ROUTES.THERAPISTS}`} className="block text-primary hover:underline">Kelola Terapis</a>
            <a href={`#${APP_ADMIN_ROUTES.USERS}`} className="block text-primary hover:underline">Lihat Pengguna</a>
            <a href={`#${APP_ADMIN_ROUTES.BOOKINGS}`} className="block text-primary hover:underline">Kelola Pemesanan</a>
            {/* <a href="#" className="block text-primary hover:underline">Pengaturan Platform</a> */}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboardPage;
