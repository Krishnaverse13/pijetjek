
import { APP_ROUTES } from '../constants.js';
import { MagnifyingGlassIcon, UserGroupIcon, CalendarDaysIcon, HomeSimpleIcon } from '../components/icons.js'; // Assuming HomeSimpleIcon for the third step

export function renderHomePage(container) {
  const homePageHTML = `
    <div class="text-center">
      <section class="py-16 bg-gradient-to-br from-primary to-secondary text-white rounded-lg shadow-xl">
        <div class="container mx-auto px-6">
          <h1 class="text-5xl font-bold mb-6">Temukan Terapis Pijat Ideal Anda</h1>
          <p class="text-xl mb-10 max-w-2xl mx-auto">
            Rasakan terapi pijat profesional dalam kenyamanan rumah Anda. Terhubung dengan terapis terampil, siap memberikan relaksasi dan kelegaan.
          </p>
          <a
            href="#${APP_ROUTES.THERAPISTS}"
            onclick="navigateTo('${APP_ROUTES.THERAPISTS}'); return false;"
            class="bg-white text-secondary hover:bg-neutral-100 font-bold py-3 px-8 rounded-lg text-lg transition-colors duration-300 shadow-md inline-flex items-center"
          >
            ${MagnifyingGlassIcon('w-5 h-5 mr-2')}
            Cari Terapis Sekarang
          </a>
        </div>
      </section>

      <section class="py-16">
        <h2 class="text-3xl font-semibold text-neutral-800 mb-12">Cara Kerjanya</h2>
        <div class="grid md:grid-cols-3 gap-10 max-w-4xl mx-auto">
          <div class="p-6 bg-white rounded-lg shadow-lg">
            ${UserGroupIcon('w-12 h-12 text-primary mx-auto mb-4')}
            <h3 class="text-xl font-semibold text-neutral-700 mb-2">1. Jelajahi Terapis</h3>
            <p class="text-neutral-600">Jelajahi profil, spesialisasi, dan ulasan terapis bersertifikat.</p>
          </div>
          <div class="p-6 bg-white rounded-lg shadow-lg">
            ${CalendarDaysIcon('w-12 h-12 text-primary mx-auto mb-4')}
            <h3 class="text-xl font-semibold text-neutral-700 mb-2">2. Pilih Layanan & Ajukan</h3>
            <p class="text-neutral-600">Pilih dari berbagai layanan pijat dan ajukan pemesanan.</p>
          </div>
          <div class="p-6 bg-white rounded-lg shadow-lg">
            ${HomeSimpleIcon('w-12 h-12 text-primary mx-auto mb-4')}
            <h3 class="text-xl font-semibold text-neutral-700 mb-2">3. Santai & Nikmati</h3>
            <p class="text-neutral-600">Terapis pilihan Anda akan datang ke tempat Anda. Nikmati pijat profesional.</p>
          </div>
        </div>
      </section>

      <section class="py-16 bg-neutral-200/70 rounded-lg">
        <h2 class="text-3xl font-semibold text-neutral-800 mb-6">Siap untuk Bersantai?</h2>
        <p class="text-lg text-neutral-700 mb-8 max-w-xl mx-auto">
          Ambil langkah pertama menuju relaksasi dan kesejahteraan. Platform kami memudahkan Anda menemukan dan memesan terapi pijat yang Anda butuhkan.
        </p>
        <a
            href="#${APP_ROUTES.THERAPISTS}"
            onclick="navigateTo('${APP_ROUTES.THERAPISTS}'); return false;"
            class="bg-primary hover:bg-secondary text-white font-bold py-3 px-8 rounded-lg text-lg transition-colors duration-300 shadow-md inline-flex items-center"
          >
            Lihat Terapis Tersedia
          </a>
      </section>
    </div>
  `;
  container.innerHTML = homePageHTML;
}
