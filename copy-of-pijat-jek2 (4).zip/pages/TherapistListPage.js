
export function renderTherapistListPage(container) {
  container.innerHTML = `
    <h1 class="text-3xl font-bold">Therapist List Page</h1>
    <p class="mt-4">This page is not yet implemented in vanilla JS.</p>
    <p class="mt-2">It will display a list of therapists with search and filter options, and a map.</p>
  `;
}
