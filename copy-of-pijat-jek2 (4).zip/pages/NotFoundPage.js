
import { APP_ROUTES } from '../constants.js';
import { ExclamationTriangleIcon } from '../components/icons.js';

export function renderNotFoundPage(container) {
  const notFoundPageHTML = `
    <div class="flex flex-col items-center justify-center text-center py-20">
      ${ExclamationTriangleIcon('w-24 h-24 text-amber-500 mb-6')}
      <h1 class="text-5xl font-bold text-neutral-800 mb-4">404 - Halaman Tidak Ditemukan</h1>
      <p class="text-xl text-neutral-600 mb-8">
        Oops! Halaman yang Anda cari sepertinya tidak ada.
      </p>
      <a
        href="#${APP_ROUTES.HOME}"
        onclick="navigateTo('${APP_ROUTES.HOME}'); return false;"
        class="bg-primary hover:bg-secondary text-white font-semibold py-3 px-6 rounded-lg transition-colors duration-300 text-lg"
      >
        Ke Beranda
      </a>
    </div>
  `;
  container.innerHTML = notFoundPageHTML;
}
